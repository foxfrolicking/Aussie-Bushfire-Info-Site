<h1>
  Assignment Info
</h1>
The key features of this site is the smoke animations and button. 

The Key issues is that I feel there could have been more improvment in the presenation of the site as it is pretty basic and there could have been more features and nicer features. The major issue is that I couldn't figure out how to make the pop up just fit the exact screen so there would be no need to scroll to find the info and exit. 

The site was used making these sites as sources for the information:
https://www.unisdr.org/2000/campaign/PDF/Articulo_6_Australia_eng.pdf
https://www.bushfirefront.org.au/home/fire-facts/impacts-of-bushfires/
https://knowledge.aidr.org.au/resources/bushfire/
https://www.fire.nsw.gov.au/page.php?id=879

And with images from:
https://unsplash.com/photos/brown-plant-in-close-up-photography-pEBNFZc8rIQ
https://unsplash.com/photos/silhouette-of-trees-during-sunset-kbTp7dBzHyY
https://unsplash.com/photos/silhouette-of-trees-during-sunset-BmDR21JiXhc

The feature codes were inspired by:
https://codepen.io/wikyware-net/pen/GRrMdZO
https://codepen.io/jamesqquick/pen/vdxEpQ